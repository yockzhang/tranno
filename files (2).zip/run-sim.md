Launch the full hauler simulation in Gazebo and run the complete cycle.

Steps:
1. Make sure the workspace is built and sourced (colcon build --symlink-install,
   then source install/setup.bash).
2. Launch the sim: ros2 launch hauler_sim hauler_sim.launch.py
3. Confirm the robot spawns on the rough-terrain world with a material pile,
   obstacles, and a drop zone.
4. Watch the state machine run: SCAN → PICKUP → CARRY → DUMP → RETURN.
5. Report which states completed, and flag any state that failed or stalled.
6. If something fails, use ros2 topic list / ros2 topic echo to diagnose what's
   flowing (or not) between nodes, and suggest a fix.

Print progress at each state transition.
