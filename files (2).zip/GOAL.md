# GOAL — Current Milestone

## The one goal right now
Produce a **working simulation demo** of the full hauler cycle on rough terrain,
that we can screen-record as proof for investors (YC / PearX / construction-tech
VCs). This is the thing that unlocks funding.

## Milestone 1 — Simulation cycle (DO THIS FIRST)
A hauler in Gazebo, on visibly rough/uneven terrain, that:

1. **SCAN** — builds a map of the site from onboard sensors.
2. **ORDER** — receives a simple order: one material type + one drop point
   (hardcoded or a basic input for now — this is the human-in-the-loop).
3. **PICKUP** — drives to the material pile, SCOOPS it into the cargo bin
   (mechanism, not a gripper).
4. **CARRY** — navigates to the drop point across rough ground, avoiding
   obstacles (tool piles, machinery, material stacks).
5. **DUMP** — rough-drops the material at the specified point (tilt bin / dump).
6. **RETURN** — loops back and repeats (this is the data-flywheel loop).

### Acceptance criteria (how we know Milestone 1 is done)
- [ ] Gazebo world has genuinely uneven terrain (not a flat plane).
- [ ] Robot model has a tracked base + a scoop/bucket + a cargo bin.
- [ ] The full SCAN→PICKUP→CARRY→DUMP→RETURN loop runs end to end.
- [ ] The robot visibly AVOIDS at least 2-3 obstacles during CARRY.
- [ ] It's real perception + decision, NOT a scripted fixed path — the robot
      responds to where the pile/obstacles/drop point are.
- [ ] Runs long enough to show 2+ complete trips (the loop).
- [ ] Screen-recordable in a single clean run.

## Milestone 2 — Self-correction (makes the demo STRONG)
After Milestone 1 works:
- [ ] After dumping, the robot senses whether material landed in the zone;
      if off, it adjusts. (Shows it's adaptive, not scripted — key for investors.)
- [ ] Vary terrain roughness / obstacle positions between runs; robot still copes.

## Milestone 3 — Material identification (adds "AI agent" credibility)
- [ ] Vision distinguishes the requested material pile from others
      (e.g. gravel vs bags vs bricks) and picks the right one.

## Explicitly NOT in scope now
- Real hardware integration (comes after sim proves out).
- Fine stacking / precise placement.
- Multiple materials in one trip.
- Stair climbing.
- The phone app UI (a stub order input is fine for now).

## Why this order
Milestone 1 proves the concept is physically real (investors see it work).
Milestone 2 proves it's an adaptive AI system, not a scripted machine.
Milestone 3 proves it's an embodied AI agent (perceives + decides).
Each milestone independently strengthens the funding pitch. Ship 1 first.

## Definition of "done" for the demo
A 60-90 second screen recording of the Gazebo sim showing the full loop on
rough terrain with obstacle avoidance and self-correction, that a non-technical
investor watches and thinks "this actually works on a real jobsite."
