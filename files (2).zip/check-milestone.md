Check current progress against the milestones in GOAL.md.

Steps:
1. Read GOAL.md.
2. For Milestone 1, go through each acceptance-criteria checkbox and determine
   from the actual code/sim whether it's met, partially met, or not started.
3. Report a clear status per checkbox (done / partial / todo) with a one-line
   reason each.
4. Identify the single most important next task to move Milestone 1 forward.
5. Do NOT jump ahead to Milestone 2 or 3 until Milestone 1 is fully done.

Be specific and honest — no vague "looks good". If a criterion isn't met, say so.
