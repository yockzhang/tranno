Create a new ROS 2 node for the hauler, wired into the existing system.

The subsystem to create: $ARGUMENTS
(e.g. "obstacle detector in perception", "scoop controller in control")

Steps:
1. Identify which package it belongs to (perception / navigation / control / interface).
2. Create the node following the topic contract in the hauler-control skill —
   document its subscribed and published topics.
3. Explain the ROS concepts involved as you go (the founder is new to ROS).
4. Add it to the relevant launch file so it starts with the sim.
5. Add a minimal test in tests/.
6. Build, source, and confirm it runs without errors.

Keep it simple and buildable. Follow the conventions and critical rules in CLAUDE.md.
