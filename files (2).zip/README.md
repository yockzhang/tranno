# Hauler CC Project — document set

This folder is a ready-to-use Claude Code project scaffold for the jobsite
material hauler robot. Drop it into your repo and CC has everything it needs
to start in the right direction.

## What's here and what each file is for

| File | Purpose |
|---|---|
| `CLAUDE.md` | **The main one.** CC reads this every session. Project definition, structure, tech stack, conventions, critical rules, anti-scope. Kept under ~200 lines so CC actually follows it. |
| `GOAL.md` | The current milestone + acceptance criteria. "What are we trying to achieve right now and how do we know it's done." Update this as milestones complete. |
| `requirements.txt` | Python dependencies. (ROS 2 / Gazebo install separately.) |
| `.claude/skills/ros-gazebo-setup/` | How to set up ROS 2 + Gazebo, workspace, the robot model. CC auto-uses it for environment work. |
| `.claude/skills/hauler-control/` | The state-machine + mechanism control logic — the backbone of the robot's behavior. |
| `.claude/commands/run-sim.md` | `/run-sim` — launch the sim and run the full cycle. |
| `.claude/commands/check-milestone.md` | `/check-milestone` — honest progress check against GOAL.md. |
| `.claude/commands/new-node.md` | `/new-node <subsystem>` — scaffold a new ROS node wired into the system. |

## How to use it

1. Put this whole folder at your repo root.
2. Open Claude Code in that folder — it auto-reads `CLAUDE.md`.
3. Point it at the current goal: "Read GOAL.md and let's start Milestone 1."
4. Work in small steps. After each chunk, run `/check-milestone`.

## Important: this is the HAULER design, not the arm

Earlier notes described a robot ARM doing pick-and-place. That design is
superseded. This project is a **scoop/cradle/carry/dump hauler** — no gripper,
no precision arm. If you paste in older material, make sure it doesn't
reintroduce the arm design. CLAUDE.md and the skills all reflect the current
hauler design.

## Best-practice reminders (from Anthropic's CC guidance)

- Keep `CLAUDE.md` lean — only what CC truly needs.
- Give CC clear acceptance criteria (that's what GOAL.md is for).
- Work in small, well-defined steps; don't dump everything at once.
- For complex tasks, have CC plan first, then execute.
- Check Anthropic's live docs for the latest:
  https://docs.claude.com/en/docs/claude-code/best-practices
