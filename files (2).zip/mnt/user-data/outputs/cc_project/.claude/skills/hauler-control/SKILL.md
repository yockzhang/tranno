---
name: hauler-control
description: Use when implementing or debugging the hauler's behavior — the SCAN/ORDER/PICKUP/CARRY/DUMP/RETURN state machine, the scoop/cradle/dump mechanism control, rough-terrain navigation with obstacle avoidance, or how the subsystems (perception, navigation, control, interface) connect. This is the backbone of the robot's logic.
---

# Hauler control logic

The robot's behavior is a state machine. Each state is one clear behavior,
implemented as (or coordinated by) a ROS 2 node. This is the spine of the whole
system — get it right and everything hangs off it.

## The state machine
```
SCAN     → scan the site, build/update the map (perception)
ORDER    → receive worker order: material type + drop point (interface)
PICKUP   → drive to material, SCOOP/CRADLE into the bin (navigation + control)
CARRY    → navigate to drop point across rough terrain, AVOID obstacles (navigation)
DUMP     → rough-drop material at the point: tilt bin / dump (control)
RETURN   → drive back, loop to SCAN for the next trip
```

Transitions happen on completion signals (reached target, bin loaded, bin empty).
Log every transition.

## Mechanism control — NOT a gripper
Material is handled by mechanism, copying human labor:
- **Gravel / loose material** → scoop bucket digs in, lifts, tips into bin.
- **Cement bags** → cradle/lift arms hug from underneath (not fingers gripping).
- **Bricks** → fork-cradle a whole stack from below.
- **Load and unload use the SAME mechanism reversed.** DUMP is PICKUP backwards.

Never implement a "grasp object" primitive. The physics of gripping heavy
material is the wall we're deliberately avoiding.

## Navigation on rough terrain
- Build a costmap that includes obstacles found during SCAN.
- Plan a path from current pose to goal (nav2, or a documented custom planner).
- Real-time obstacle avoidance during CARRY — the robot must respond to obstacles,
  not follow a fixed scripted path. (Investors need to see genuine avoidance.)
- Assume uneven ground: tune for traction/tipping, not speed.

## Subsystem topics (document as you build)
Rough contract between nodes — refine as implemented:
- perception → `/map`, `/material_piles`, `/obstacles`
- interface  → `/order` (material_type, drop_point)
- navigation → `/cmd_vel`, `/path`; subscribes `/map`, `/order`
- control    → `/scoop_cmd`, `/bin_cmd`; publishes `/state`

## The human-in-the-loop principle
The worker decides WHAT and WHERE (via the order). The robot handles HOW
(perceive, plan, scoop, navigate, dump). Do not try to make the robot
autonomously decide what to deliver in v1 — that's the hard AI problem we're
deliberately deferring. The order input can be a stub for now.

## What makes the demo strong (build toward this)
1. Basic: the full loop runs (Milestone 1).
2. Strong: after DUMP, sense if material landed in-zone; if not, self-correct
   (Milestone 2) — this proves it's adaptive, not scripted.
3. Agent: vision identifies the correct material pile among several
   (Milestone 3) — proves perception + decision.

## Keep it buildable
Prefer the simplest mechanism/algorithm that demonstrates the behavior. A
solo founder + CC has to build and debug this. A rough scoop that works beats
an elegant manipulator that doesn't. Add sophistication only after the loop runs.
