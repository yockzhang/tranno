# Jobsite Material Hauler — Robot Project

## What this is
An autonomous material-handling robot for residential construction sites.
A tracked (crawler) base that SCOOPS / CRADLES / CARRIES / DUMPS building
materials across rough terrain and delivers them where a worker asks.

**It is NOT a robot arm doing pick-and-place.** It copies how a human laborer
works: scoop gravel with a bucket, cradle cement bags, carry bricks in a bin,
dump at the drop point. No precise "gripping" — that avoids the payload/weight
physics wall entirely.

Human-in-the-loop: worker taps a phone (what material + where) → robot executes.

## The moat (why this matters, keep it in mind)
Rough terrain. Warehouse/general robots need flat structured floors and fail on
mud, gravel, debris, slopes. Our whole reason to exist is working where they
can't. Never optimize toward clean/indoor assumptions.

## Development strategy
Build and validate in SIMULATION first (ROS 2 + Gazebo), before touching real
hardware. Hardware (tracked chassis + scoop/bin) is being sourced separately.
The human founder has a CS background but is new to ROS — explain ROS concepts
as you introduce them.

## Project structure
```
hauler/
├── CLAUDE.md                    ← you are here
├── GOAL.md                      ← current milestone + acceptance criteria
├── requirements.txt
├── sim/                         ← Gazebo world + robot model (URDF/SDF)
│   ├── worlds/                  ← rough-terrain jobsite world
│   └── models/                  ← hauler model (base + scoop + bin)
├── src/
│   ├── perception/              ← mapping + material identification
│   ├── navigation/              ← rough-terrain path planning + obstacle avoidance
│   ├── control/                 ← scoop / carry / dump state machine
│   └── interface/               ← phone-order input (what material + where)
├── launch/                      ← ROS 2 launch files
├── config/                      ← params
└── tests/
```

## Run commands
```bash
# install deps
pip install -r requirements.txt

# launch the full simulation
ros2 launch launch/hauler_sim.launch.py

# run one subsystem in isolation
ros2 run control state_machine
ros2 run navigation planner
```

## Tech stack
- ROS 2 (Humble or newer)
- Gazebo (simulation)
- Python primary; C++ only where real-time control needs it
- Perception: OpenCV + a depth camera model in sim
- Navigation: nav2 stack (or a documented custom planner)

## Key conventions
- Every subsystem is a ROS 2 node with clear topics in/out — document them.
- State machine states are the backbone: SCAN → ORDER → PICKUP(scoop/cradle)
  → CARRY(navigate+avoid) → DUMP(rough-drop) → RETURN. One state = one clear
  behavior.
- Material handling is by MECHANISM, never a gripper:
  gravel → scoop bucket; bags → cradle/lift; bricks → fork-cradle a whole stack.
- Load and unload are the SAME mechanism reversed.
- Coordinates: meters, SI units, REP-103 frame conventions (x-forward, z-up).
- Progress: print/log at each state transition.

## Critical rules
1. NEVER assume flat/indoor terrain. Rough ground is the whole point.
2. NEVER design a solution that requires a heavy precision arm — mechanism, not gripping.
3. Keep the human-in-the-loop: the worker specifies material + drop point;
   the robot does not need to autonomously decide WHAT to deliver in v1.
4. Simulation before hardware — always validate in Gazebo first.
5. Handle missing perception gracefully — log, don't crash.
6. When unsure about a design tradeoff, prefer the SIMPLER mechanism that a
   solo founder + CC can actually build and debug.
7. Explain ROS concepts as you go — the founder is new to ROS.

## Anti-scope (do NOT build in v1)
- No fine stacking / precise placement (rough-drop only).
- No multi-material intelligent scheduling (one material type first).
- No stair climbing.
- No full autonomy deciding what to deliver (worker orders it).

See GOAL.md for the current milestone and acceptance criteria.
